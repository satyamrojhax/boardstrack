-- Create community_messages table for real-time chat
CREATE TABLE IF NOT EXISTS community_messages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create prompt_questions table for storing prompt-based questions
CREATE TABLE IF NOT EXISTS prompt_questions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  prompt TEXT NOT NULL,
  question_type VARCHAR(50) NOT NULL, -- 'short' or 'long'
  generated_questions JSONB NOT NULL,
  subject VARCHAR(100),
  chapter VARCHAR(100),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create mcq_questions table for storing MCQ questions
CREATE TABLE IF NOT EXISTS mcq_questions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  question TEXT NOT NULL,
  options JSONB NOT NULL, -- Array of 4 options
  correct_answer INTEGER NOT NULL, -- 0-3 index
  explanation TEXT,
  subject VARCHAR(100),
  chapter VARCHAR(100),
  difficulty VARCHAR(20) DEFAULT 'medium',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create quiz_sessions table for tracking quiz performance
CREATE TABLE IF NOT EXISTS quiz_sessions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  quiz_type VARCHAR(50) NOT NULL, -- 'mcq' or 'general'
  total_questions INTEGER NOT NULL,
  correct_answers INTEGER NOT NULL,
  score_percentage INTEGER NOT NULL,
  time_taken INTEGER, -- in seconds
  subject VARCHAR(100),
  chapter VARCHAR(100),
  completed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user_profiles table for extended user information
CREATE TABLE IF NOT EXISTS user_profiles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  display_name VARCHAR(100),
  avatar_url TEXT,
  bio TEXT,
  class_level VARCHAR(20) DEFAULT 'Class 10th',
  favorite_subjects JSONB,
  study_streak INTEGER DEFAULT 0,
  total_questions_solved INTEGER DEFAULT 0,
  total_quizzes_completed INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE community_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE prompt_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE mcq_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies for community_messages (all authenticated users can read, only owner can insert/update/delete)
CREATE POLICY "Users can view all community messages" ON community_messages
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Users can insert their own messages" ON community_messages
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own messages" ON community_messages
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own messages" ON community_messages
  FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for prompt_questions (only owner can access)
CREATE POLICY "Users can view their own prompt questions" ON prompt_questions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own prompt questions" ON prompt_questions
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own prompt questions" ON prompt_questions
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own prompt questions" ON prompt_questions
  FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for mcq_questions (only owner can access)
CREATE POLICY "Users can view their own MCQ questions" ON mcq_questions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own MCQ questions" ON mcq_questions
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own MCQ questions" ON mcq_questions
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own MCQ questions" ON mcq_questions
  FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for quiz_sessions (only owner can access)
CREATE POLICY "Users can view their own quiz sessions" ON quiz_sessions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own quiz sessions" ON quiz_sessions
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own quiz sessions" ON quiz_sessions
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own quiz sessions" ON quiz_sessions
  FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for user_profiles (users can view all profiles but only update their own)
CREATE POLICY "Users can view all user profiles" ON user_profiles
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Users can insert their own profile" ON user_profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile" ON user_profiles
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own profile" ON user_profiles
  FOR DELETE USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_community_messages_created_at ON community_messages(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_community_messages_user_id ON community_messages(user_id);
CREATE INDEX IF NOT EXISTS idx_prompt_questions_user_id ON prompt_questions(user_id);
CREATE INDEX IF NOT EXISTS idx_prompt_questions_created_at ON prompt_questions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mcq_questions_user_id ON mcq_questions(user_id);
CREATE INDEX IF NOT EXISTS idx_mcq_questions_subject ON mcq_questions(subject);
CREATE INDEX IF NOT EXISTS idx_quiz_sessions_user_id ON quiz_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_quiz_sessions_completed_at ON quiz_sessions(completed_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);

-- Create function to automatically create user profile on signup
CREATE OR REPLACE FUNCTION create_user_profile()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_profiles (user_id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically create user profile
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION create_user_profile();

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
CREATE TRIGGER update_user_profiles_updated_at
  BEFORE UPDATE ON user_profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_community_messages_updated_at
  BEFORE UPDATE ON community_messages
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

