import { useState, useEffect, lazy, Suspense, memo } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { SyllabusProvider } from "@/contexts/SyllabusContext";
import { TimerProvider } from "@/contexts/TimerContext";
import ErrorBoundary from "@/components/ErrorBoundary";
import LoadingSpinner from "@/components/LoadingSpinner";
import MainLayout from "./components/MainLayout";
import SplashScreen from "./components/SplashScreen";

// Optimized lazy loading with preloading
const Index = lazy(() => import("./pages/Index"));
const Auth = lazy(() => import("./pages/Auth"));
const Profile = lazy(() => import("./pages/Profile"));
const NotFound = lazy(() => import("./pages/NotFound"));
const SyllabusPage = lazy(() => import("./pages/SyllabusPage"));
const QuestionsPage = lazy(() => import("./pages/QuestionsPage"));
const PredictorPage = lazy(() => import("./pages/PredictorPage"));
const DoubtsPage = lazy(() => import("./pages/DoubtsPage"));
const HistoryPage = lazy(() => import("./pages/HistoryPage"));
const TimerPage = lazy(() => import("./pages/TimerPage"));
const NotesPage = lazy(() => import("./pages/NotesPage"));
const BadgesPage = lazy(() => import("./pages/BadgesPage"));
const ExportPage = lazy(() => import("./pages/ExportPage"));
const ThemePage = lazy(() => import("./pages/ThemePage"));
const ToDoPage = lazy(() => import("./pages/ToDoPage"));
const VerifyEmail = lazy(() => import("./pages/VerifyEmail"));
const PromptQuestionsPage = lazy(() => import("./pages/PromptQuestionsPage"));
const MCQGeneratorPage = lazy(() => import("./pages/MCQGeneratorPage"));

// Optimized QueryClient with better caching
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 10 * 60 * 1000, // 10 minutes
      gcTime: 30 * 60 * 1000, // 30 minutes
      retry: 1,
      refetchOnWindowFocus: false,
      refetchOnReconnect: true,
      refetchOnMount: false,
    },
    mutations: {
      retry: 1,
    },
  },
});

// Memoized loading component
const OptimizedLoadingSpinner = memo(() => (
  <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
    <div className="text-center space-y-4">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
      <p className="text-sm text-muted-foreground">Loading...</p>
    </div>
  </div>
));

// Memoized App Routes
const AppRoutes = memo(() => {
  const { user, loading } = useAuth();
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    // Reduce splash screen time for faster perceived loading
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 1500); // Reduced from 2000ms to 1500ms

    return () => clearTimeout(timer);
  }, []);

  // Preload critical components when app starts
  useEffect(() => {
    if (!loading && user) {
      // Preload commonly used components
      import("./pages/QuestionsPage");
      import("./pages/ToDoPage");
      import("./pages/MCQGeneratorPage");
    }
  }, [loading, user]);

  if (showSplash) {
    return <SplashScreen />;
  }

  if (loading) {
    return <OptimizedLoadingSpinner />;
  }

  if (!user) {
    return (
      <Suspense fallback={<OptimizedLoadingSpinner />}>
        <Routes>
          <Route path="*" element={<Auth />} />
        </Routes>
      </Suspense>
    );
  }

  return (
    <MainLayout>
      <Suspense fallback={<OptimizedLoadingSpinner />}>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/syllabus" element={<SyllabusPage />} />
          <Route path="/questions" element={<QuestionsPage />} />
          <Route path="/predictor" element={<PredictorPage />} />
          <Route path="/doubts" element={<DoubtsPage />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/timer" element={<TimerPage />} />
          <Route path="/notes" element={<NotesPage />} />
          <Route path="/badges" element={<BadgesPage />} />
          <Route path="/export" element={<ExportPage />} />
          <Route path="/theme" element={<ThemePage />} />
          <Route path="/todo" element={<ToDoPage />} />
          <Route path="/verify-email" element={<VerifyEmail />} />
          <Route path="/prompt-questions" element={<PromptQuestionsPage />} />
          <Route path="/mcq-generator" element={<MCQGeneratorPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </MainLayout>
  );
});

// Main App component with optimizations
function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <ThemeProvider>
            <AuthProvider>
              <SyllabusProvider>
                <TimerProvider>
                  <TooltipProvider>
                    <AppRoutes />
                    <Toaster />
                    <Sonner />
                  </TooltipProvider>
                </TimerProvider>
              </SyllabusProvider>
            </AuthProvider>
          </ThemeProvider>
        </BrowserRouter>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default memo(App);

