import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'

// Preload critical resources
const preloadCriticalResources = () => {
  // Preload fonts
  const fontLink = document.createElement('link');
  fontLink.rel = 'preload';
  fontLink.as = 'font';
  fontLink.type = 'font/woff2';
  fontLink.crossOrigin = 'anonymous';
  document.head.appendChild(fontLink);
};

// Initialize app with performance optimizations
const initializeApp = () => {
  const root = createRoot(document.getElementById("root")!);
  
  // Use concurrent features for better performance
  root.render(<App />);
  
  // Add smooth scrolling behavior globally
  document.documentElement.style.scrollBehavior = 'smooth';
  
  // Optimize touch events for mobile
  document.addEventListener('touchstart', () => {}, { passive: true });
  document.addEventListener('touchmove', () => {}, { passive: true });
  
  // Prevent unnecessary reflows
  document.body.style.overflow = 'hidden auto';
  
  // Add viewport meta for better mobile performance
  if (!document.querySelector('meta[name="viewport"]')) {
    const viewport = document.createElement('meta');
    viewport.name = 'viewport';
    viewport.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
    document.head.appendChild(viewport);
  }
};

// Preload resources and initialize
preloadCriticalResources();

// Use requestIdleCallback for non-critical initialization
if ('requestIdleCallback' in window) {
  requestIdleCallback(initializeApp);
} else {
  // Fallback for browsers without requestIdleCallback
  setTimeout(initializeApp, 1);
}

// Service Worker registration for caching (if available)
if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then(() => console.log('SW registered'))
      .catch(() => console.log('SW registration failed'));
  });
}

