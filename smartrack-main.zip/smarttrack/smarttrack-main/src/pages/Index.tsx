import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useSyllabus } from '@/contexts/SyllabusContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import {
  Brain,
  BookOpen,
  Target,
  Users,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Award,
  Star,
  History,
  Clock,
  CheckCircle,
  Zap,
  Calendar,
  Trophy,
  BarChart3,
  Flame,
  Timer,
  HelpCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';

const Index = () => {
  const { subjects, getOverallProgress } = useSyllabus();
  const { profile } = useAuth();
  const overallProgress = getOverallProgress();
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  const totalChapters = subjects.reduce((total, subject) => total + subject.chapters.length, 0);
  const completedChapters = subjects.reduce(
    (total, subject) => total + subject.chapters.filter(chapter => chapter.completed).length,
    0
  );

  const recentlyStudied = subjects
    .flatMap(subject =>
      subject.chapters
        .filter(chapter => chapter.completed)
        .map(chapter => ({ ...chapter, subject: subject.name, icon: subject.icon }))
    )
    .slice(-3);

  const getGreeting = () => {
    const hour = currentTime.getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const getMotivationalMessage = () => {
    const messages = [
      "Ready to conquer your studies today? 🚀",
      "Every question you solve brings you closer to success! 💪",
      "Your dedication today shapes your tomorrow! ⭐",
      "Small steps lead to big achievements! 🎯",
      "Keep pushing forward, you're doing great! 🌟"
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  };

  // Fetch user statistics from backend
  const [userStats, setUserStats] = useState({
    studyStreak: 0,
    questionsToday: 0,
    totalQuestions: 0,
    studyTimeToday: 0
  });

  useEffect(() => {
    const fetchUserStats = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        // Fetch study streak and questions data
        const today = new Date().toISOString().split('T')[0];
        
        // Get questions answered today
        const { data: questionsData } = await supabase
          .from('user_generated_questions')
          .select('id, created_at')
          .eq('user_id', user.id)
          .gte('created_at', today + 'T00:00:00.000Z')
          .lte('created_at', today + 'T23:59:59.999Z');

        // Get total questions
        const { data: totalQuestionsData } = await supabase
          .from('user_generated_questions')
          .select('id')
          .eq('user_id', user.id);

        // Calculate study streak (simplified - count consecutive days with activity)
        const { data: recentActivity } = await supabase
          .from('user_generated_questions')
          .select('created_at')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(30);

        let streak = 0;
        if (recentActivity && recentActivity.length > 0) {
          const dates = [...new Set(recentActivity.map(item => 
            new Date(item.created_at).toISOString().split('T')[0]
          ))].sort().reverse();
          
          const today = new Date().toISOString().split('T')[0];
          let currentDate = new Date(today);
          
          for (const date of dates) {
            const checkDate = currentDate.toISOString().split('T')[0];
            if (date === checkDate) {
              streak++;
              currentDate.setDate(currentDate.getDate() - 1);
            } else {
              break;
            }
          }
        }

        setUserStats({
          studyStreak: streak,
          questionsToday: questionsData?.length || 0,
          totalQuestions: totalQuestionsData?.length || 0,
          studyTimeToday: 0 // This would need a separate tracking mechanism
        });

      } catch (error) {
        console.error('Error fetching user stats:', error);
      }
    };

    fetchUserStats();
  }, []);

  // Dummy data for now, will be replaced with actual data from backend if available
  const studyStreak = userStats.studyStreak;
  const todayQuestions = userStats.questionsToday;

  const quickStats = [
    {
      icon: Flame,
      label: 'Study Streak',
      value: `${studyStreak} days`,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50 dark:bg-orange-900/20'
    },
    {
      icon: Brain,
      label: 'Questions Today',
      value: todayQuestions,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50 dark:bg-purple-900/20'
    },
    {
      icon: Trophy,
      label: 'Completion',
      value: `${overallProgress}%`,
      color: 'text-green-600',
      bgColor: 'bg-green-50 dark:bg-green-900/20'
    },
    {
      icon: BarChart3,
      label: 'Subjects Active',
      value: subjects.length,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50 dark:bg-blue-900/20'
    }
  ];

  const features = [
    {
      icon: Brain,
      title: 'AI Question Generator',
      description: 'Generate unlimited practice questions tailored to your syllabus',
      color: 'from-purple-400 to-pink-600',
      link: '/questions',
      badge: 'Popular'
    },
    {
      icon: Target,
      title: 'MCQ Practice',
      description: 'Interactive multiple choice questions with instant feedback',
      color: 'from-blue-400 to-indigo-600',
      link: '/mcq-generator',
      badge: 'New'
    },
    {
      icon: HelpCircle,
      title: 'Doubt Solver',
      description: 'Get instant answers to your study questions',
      color: 'from-green-400 to-emerald-600',
      link: '/doubts',
      badge: 'AI Powered'
    },
    {
      icon: BookOpen,
      title: 'Progress Tracker',
      description: 'Comprehensive CBSE Class 10 curriculum tracking',
      color: 'from-orange-400 to-red-600',
      link: '/syllabus',
      badge: 'Essential'
    }
  ];

  const quickActions = [
    {
      icon: Brain,
      title: 'Generate Questions',
      description: 'AI-powered practice',
      link: '/questions',
      color: 'text-purple-600',
      bgColor: 'hover:bg-purple-50 dark:hover:bg-purple-900/20'
    },
    {
      icon: Target,
      title: 'MCQ Quiz',
      description: 'Quick practice test',
      link: '/mcq-generator',
      color: 'text-blue-600',
      bgColor: 'hover:bg-blue-50 dark:hover:bg-blue-900/20'
    },
    {
      icon: HelpCircle,
      title: 'Ask Doubts',
      description: 'Get instant help',
      link: '/doubts',
      color: 'text-green-600',
      bgColor: 'hover:bg-green-50 dark:hover:bg-green-900/20'
    },
    {
      icon: BookOpen,
      title: 'Track Progress',
      description: 'View syllabus',
      link: '/syllabus',
      color: 'text-orange-600',
      bgColor: 'hover:bg-orange-50 dark:hover:bg-orange-900/20'
    },
    {
      icon: History,
      title: 'Study History',
      description: 'Review past work',
      link: '/history',
      color: 'text-indigo-600',
      bgColor: 'hover:bg-indigo-50 dark:hover:bg-indigo-900/20'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/50 to-accent/5">
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6 sm:space-y-8">
        {/* Welcome Header */}
        <div className="text-center space-y-4 sm:space-y-6 py-6 sm:py-8 animate-fade-in">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-primary/10 to-secondary/10 px-4 py-2 rounded-full text-sm border border-primary/20">
            <Sparkles className="w-4 h-4 text-primary animate-pulse" />
            <span className="text-primary font-medium">
              {getGreeting()}, {profile?.name?.split(' ')[0] || 'Student'}!
            </span>
            <Clock className="w-4 h-4 text-muted-foreground" />
            <span className="text-muted-foreground text-xs">
              {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>

          <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold bg-gradient-to-r from-primary via-purple-600 to-blue-600 bg-clip-text text-transparent leading-tight">
            Your AI Study
            <br />
            <span className="text-primary">Dashboard</span>
          </h1>

          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto px-4">
            {getMotivationalMessage()}
          </p>

          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-center px-4">
            <Link to="/questions">
              <Button size="lg" className="w-full sm:w-auto px-6 sm:px-8 py-3 sm:py-6 text-base sm:text-lg smooth-transition hover:scale-105 bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90">
                <Brain className="w-5 h-5 mr-2" />
                Start Studying
              </Button>
            </Link>
            <Link to="/mcq-generator">
              <Button variant="outline" size="lg" className="w-full sm:w-auto px-6 sm:px-8 py-3 sm:py-6 text-base sm:text-lg smooth-transition hover:scale-105 border-2">
                <Target className="w-5 h-5 mr-2" />
                Take Quiz
              </Button>
            </Link>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-6">
          {quickStats.map((stat, index) => (
            <Card key={index} className="glass-card smooth-transition hover:shadow-lg hover:scale-105 border-0 bg-gradient-to-br from-white to-gray-50/50 dark:from-gray-800 dark:to-gray-900/50">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 sm:p-3 rounded-xl ${stat.bgColor}`}>
                    <stat.icon className={`w-5 h-5 sm:w-6 sm:h-6 ${stat.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-lg sm:text-2xl font-bold text-foreground">{stat.value}</p>
                    <p className="text-xs sm:text-sm text-muted-foreground truncate">{stat.label}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Progress Overview */}
        <Card className="glass-card smooth-transition hover:shadow-lg border-0 bg-gradient-to-br from-white to-gray-50/50 dark:from-gray-800 dark:to-gray-900/50">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center space-x-2 text-lg sm:text-xl">
              <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-green-600" />
              <span>Learning Progress</span>
              <Badge variant="secondary" className="ml-auto">Live</Badge>
            </CardTitle>
            <CardDescription className="text-sm sm:text-base">Track your journey across all subjects</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
              <div className="text-center space-y-2 p-4 bg-gradient-to-br from-primary/5 to-primary/10 rounded-xl border border-primary/20">
                <div className="text-2xl sm:text-3xl font-bold text-primary">{overallProgress}%</div>
                <p className="text-sm text-muted-foreground">Overall Completion</p>
                <Progress value={overallProgress} className="h-2 sm:h-3" />
              </div>
              <div className="text-center space-y-2 p-4 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-xl border border-green-200 dark:border-green-800">
                <div className="text-2xl sm:text-3xl font-bold text-green-600">{completedChapters}</div>
                <p className="text-sm text-muted-foreground">Chapters Done</p>
                <Badge variant="outline" className="text-xs">{totalChapters} Total</Badge>
              </div>
              <div className="text-center space-y-2 p-4 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl border border-blue-200 dark:border-blue-800">
                <div className="text-2xl sm:text-3xl font-bold text-blue-600">{subjects.length}</div>
                <p className="text-sm text-muted-foreground">Active Subjects</p>
                <Badge variant="secondary" className="text-xs">CBSE Board</Badge>
              </div>
            </div>

            {recentlyStudied.length > 0 && (
              <div className="space-y-3 p-4 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 rounded-xl border border-amber-200 dark:border-amber-800">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <h4 className="font-medium text-sm text-muted-foreground">Recently Completed</h4>
                </div>
                <div className="flex flex-wrap gap-2">
                  {recentlyStudied.map((chapter, index) => (
                    <Badge key={index} variant="outline" className="flex items-center space-x-1 bg-white dark:bg-gray-800">
                      <span>{chapter.icon}</span>
                      <span className="text-xs">{chapter.name}</span>
                      <CheckCircle className="w-3 h-3 text-green-600" />
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {features.map((feature, index) => (
            <Link key={index} to={feature.link} className="group">
              <Card className="glass-card smooth-transition hover:shadow-xl hover:scale-105 group border-0 bg-gradient-to-br from-white to-gray-50/50 dark:from-gray-800 dark:to-gray-900/50 h-full">
                <CardHeader className="pb-4">
                  <div className="relative">
                    <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-gradient-to-r ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 smooth-transition shadow-lg`}>
                      <feature.icon className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
                    </div>
                    {feature.badge && (
                      <Badge className="absolute -top-2 -right-2 text-xs bg-gradient-to-r from-primary to-purple-600 text-white">
                        {feature.badge}
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-base sm:text-lg group-hover:text-primary smooth-transition">{feature.title}</CardTitle>
                  <CardDescription className="text-sm">{feature.description}</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center text-primary opacity-0 group-hover:opacity-100 smooth-transition">
                    <span className="text-sm font-medium">Get Started</span>
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 smooth-transition" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Quick Actions */}
        <Card className="glass-card smooth-transition border-0 bg-gradient-to-br from-white to-gray-50/50 dark:from-gray-800 dark:to-gray-900/50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-lg sm:text-xl">
              <Zap className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-600" />
              <span>Quick Actions</span>
              <Badge variant="outline" className="ml-auto">Shortcuts</Badge>
            </CardTitle>
            <CardDescription className="text-sm sm:text-base">Jump into your study session instantly</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
              {quickActions.map((action, index) => (
                <Link key={index} to={action.link} className="group">
                  <div className={`p-4 sm:p-6 border rounded-xl smooth-transition hover:shadow-md hover:border-primary group-hover:scale-105 ${action.bgColor} bg-white dark:bg-gray-800`}>
                    <action.icon className={`w-6 h-6 sm:w-8 sm:h-8 ${action.color} mb-2 sm:mb-3 group-hover:scale-110 smooth-transition`} />
                    <h4 className="font-medium text-sm sm:text-base mb-1">{action.title}</h4>
                    <p className="text-xs sm:text-sm text-muted-foreground mb-2">{action.description}</p>
                    <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4 ${action.color} opacity-0 group-hover:opacity-100 smooth-transition" />
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Subject Overview */}
        <Card className="glass-card smooth-transition border-0 bg-gradient-to-br from-white to-gray-50/50 dark:from-gray-800 dark:to-gray-900/50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-lg sm:text-xl">
              <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 text-indigo-600" />
              <span>Subject Overview</span>
              <Badge variant="secondary" className="ml-auto">CBSE Class 10</Badge>
            </CardTitle>
            <CardDescription className="text-sm sm:text-base">Your progress across all subjects</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {subjects.slice(0, 6).map((subject) => {
                const completedCount = subject.chapters.filter(ch => ch.completed).length;
                const progress = (completedCount / subject.chapters.length) * 100;

                return (
                  <div key={subject.id} className="p-4 sm:p-6 border rounded-xl smooth-transition hover:shadow-md hover:scale-105 bg-white dark:bg-gray-800 group">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="p-2 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-lg group-hover:scale-110 smooth-transition">
                        <span className="text-xl sm:text-2xl">{subject.icon}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm sm:text-base truncate">{subject.name}</h4>
                        <p className="text-xs sm:text-sm text-muted-foreground">{completedCount}/{subject.chapters.length} chapters</p>
                      </div>
                      {progress === 100 && (
                        <CheckCircle className="w-5 h-5 text-green-600 animate-pulse" />
                      )}
                    </div>
                    <Progress value={progress} className="h-2 sm:h-3 mb-2" />
                    <div className="flex justify-between items-center">
                      <p className="text-xs sm:text-sm text-muted-foreground">{Math.round(progress)}% complete</p>
                      {progress > 0 && (
                        <Badge variant="outline" className="text-xs">
                          {progress >= 100 ? 'Complete' : 'In Progress'}
                        </Badge>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {subjects.length > 6 && (
              <div className="text-center mt-6">
                <Link to="/syllabus">
                  <Button variant="outline" className="smooth-transition hover:scale-105 px-6 py-3">
                    View All Subjects
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Study Tips */}
        <Card className="glass-card smooth-transition border-0 bg-gradient-to-br from-primary/5 to-secondary/5">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-lg sm:text-xl">
              <Star className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-600" />
              <span>Study Tip of the Day</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="p-4 sm:p-6 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-xl border border-yellow-200 dark:border-yellow-800">
              <p className="text-sm sm:text-base text-foreground font-medium mb-2">
                💡 Practice Active Recall
              </p>
              <p className="text-sm text-muted-foreground">
                Instead of just re-reading notes, test yourself by trying to recall information without looking.
                This strengthens memory and improves long-term retention!
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Index;

