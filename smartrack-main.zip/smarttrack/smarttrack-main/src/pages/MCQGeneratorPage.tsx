import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useToast } from "@/hooks/use-toast";
import { useSyllabus } from '@/contexts/SyllabusContext';
import { Brain, Sparkles, Copy, Download, CheckCircle, Circle, Play, RotateCcw, Trophy, Target } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

interface MCQQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
  subject: string;
  chapter: string;
  difficulty: string;
}

const MCQGeneratorPage: React.FC = () => {
  const { subjects } = useSyllabus();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    selectedSubject: '',
    selectedChapter: '',
    questionCount: '5'
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [generatedQuestions, setGeneratedQuestions] = useState<MCQQuestion[]>([]);
  const [selectedAnswers, setSelectedAnswers] = useState<{[key: string]: number}>({});
  const [showResults, setShowResults] = useState(false);
  const [quizMode, setQuizMode] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [quizScore, setQuizScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [showSolutions, setShowSolutions] = useState<{[key: string]: boolean}>({});

  const selectedSubjectData = subjects.find(s => s.id === formData.selectedSubject);
  const availableChapters = selectedSubjectData?.chapters || [];

  const generateMCQs = async () => {
    if (!formData.selectedSubject || !formData.selectedChapter) {
      toast({
        title: "Missing Information",
        description: "Please select subject and chapter",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      const subjectName = selectedSubjectData?.name || '';
      const chapterName = availableChapters.find(ch => ch.id === formData.selectedChapter)?.name || '';
      
      const prompt = `Generate exactly ${formData.questionCount} Multiple Choice Questions (MCQs) for CBSE Class 10th ${subjectName} - Chapter: ${chapterName}.

IMPORTANT REQUIREMENTS:
- Focus on IMPORTANT QUESTIONS and PYQs (Previous Year Questions) style
- Each question should be exam-oriented and conceptually important
- Include questions that frequently appear in CBSE exams
- Cover key concepts, formulas, and applications from the chapter

Format each question as follows:

**Question X:**
[Question text]

**Options:**
A) [Option 1]
B) [Option 2] 
C) [Option 3]
D) [Option 4]

**Correct Answer:** [A/B/C/D]

**Explanation:** [Brief explanation of why this answer is correct]

---

Make sure to:
- Generate exactly ${formData.questionCount} questions
- Focus on important concepts and PYQ patterns
- Ensure all options are plausible
- Provide clear explanations
- Cover different difficulty levels (easy to moderate)
- Include both theoretical and application-based questions`;

      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyDi1wHRLfS2-g4adHzuVfZRzmI4tRrzH-U`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: prompt
            }]
          }]
        })
      });

      if (!response.ok) {
        throw new Error('Failed to generate MCQs');
      }

      const data = await response.json();
      const generatedText = data.candidates[0].content.parts[0].text;
      
      // Parse the generated MCQs
      const questions = parseMCQs(generatedText, subjectName, chapterName);
      setGeneratedQuestions(questions);
      setSelectedAnswers({});
      setShowResults(false);
      setQuizMode(false);
      setCurrentQuestionIndex(0);
      setQuizCompleted(false);
      setQuizScore(0);
      setShowSolutions({});
      
      toast({
        title: "MCQs Generated Successfully! 🎉",
        description: `Created ${questions.length} important MCQ questions for practice`,
      });

    } catch (error) {
      console.error('Error generating MCQs:', error);
      toast({
        title: "Generation Failed",
        description: "Unable to create MCQs right now. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const parseMCQs = (text: string, subject: string, chapter: string): MCQQuestion[] => {
    const questions: MCQQuestion[] = [];
    const questionBlocks = text.split('---').filter(block => block.trim());

    questionBlocks.forEach((block, index) => {
      const lines = block.trim().split('\n').filter(line => line.trim());
      
      if (lines.length > 0) {
        let questionText = '';
        let options: string[] = [];
        let correctAnswer = 0;
        let explanation = '';
        
        let currentSection = '';
        
        for (const line of lines) {
          const trimmedLine = line.trim();
          
          if (trimmedLine.startsWith('**Question')) {
            currentSection = 'question';
            continue;
          } else if (trimmedLine.startsWith('**Options:**')) {
            currentSection = 'options';
            continue;
          } else if (trimmedLine.startsWith('**Correct Answer:**')) {
            currentSection = 'answer';
            const answerMatch = trimmedLine.match(/\*\*Correct Answer:\*\*\s*([ABCD])/);
            if (answerMatch) {
              correctAnswer = answerMatch[1].charCodeAt(0) - 65; // Convert A,B,C,D to 0,1,2,3
            }
            continue;
          } else if (trimmedLine.startsWith('**Explanation:**')) {
            currentSection = 'explanation';
            continue;
          }
          
          if (currentSection === 'question' && trimmedLine && !trimmedLine.startsWith('**')) {
            questionText += trimmedLine + ' ';
          } else if (currentSection === 'options' && trimmedLine.match(/^[ABCD]\)/)) {
            options.push(trimmedLine.substring(2).trim());
          } else if (currentSection === 'explanation' && trimmedLine && !trimmedLine.startsWith('**')) {
            explanation += trimmedLine + ' ';
          }
        }
        
        if (questionText.trim() && options.length === 4) {
          questions.push({
            id: `mcq-${index + 1}`,
            question: questionText.trim(),
            options,
            correctAnswer,
            explanation: explanation.trim() || undefined,
            subject,
            chapter,
            difficulty: 'medium'
          });
        }
      }
    });

    return questions;
  };

  const handleAnswerSelect = (questionId: string, answerIndex: number) => {
    if (quizMode && !quizCompleted) {
      setSelectedAnswers(prev => ({
        ...prev,
        [questionId]: answerIndex
      }));
    } else if (!showResults) {
      setSelectedAnswers(prev => ({
        ...prev,
        [questionId]: answerIndex
      }));
    }
  };

  const startQuizMode = () => {
    setQuizMode(true);
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
    setQuizScore(0);
    setQuizCompleted(false);
    setShowSolutions({});
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < generatedQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      completeQuiz();
    }
  };

  const previousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const completeQuiz = () => {
    const correct = generatedQuestions.filter(q => selectedAnswers[q.id] === q.correctAnswer).length;
    setQuizScore(correct);
    setQuizCompleted(true);
    
    toast({
      title: "Quiz Completed! 🎉",
      description: `You scored ${correct}/${generatedQuestions.length} (${Math.round((correct/generatedQuestions.length)*100)}%)`,
    });
  };

  const resetQuiz = () => {
    setQuizMode(false);
    setSelectedAnswers({});
    setShowResults(false);
    setCurrentQuestionIndex(0);
    setQuizCompleted(false);
    setQuizScore(0);
    setShowSolutions({});
  };

  const checkAnswers = () => {
    setShowResults(true);
    const correct = generatedQuestions.filter(q => selectedAnswers[q.id] === q.correctAnswer).length;
    const total = generatedQuestions.length;
    
    toast({
      title: "Results Ready! 📊",
      description: `You scored ${correct}/${total} (${Math.round((correct/total)*100)}%)`,
    });
  };

  const toggleSolution = (questionId: string) => {
    setShowSolutions(prev => ({
      ...prev,
      [questionId]: !prev[questionId]
    }));
  };

  const copyQuestion = (question: MCQQuestion) => {
    const text = `${question.question}\n\nA) ${question.options[0]}\nB) ${question.options[1]}\nC) ${question.options[2]}\nD) ${question.options[3]}\n\nCorrect Answer: ${String.fromCharCode(65 + question.correctAnswer)}\n\n${question.explanation ? `Explanation: ${question.explanation}` : ''}`;
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied! 📋",
      description: "MCQ copied to clipboard",
    });
  };

  const exportMCQs = () => {
    const content = generatedQuestions.map((q, index) => 
      `Question ${index + 1}: ${q.question}\n\nA) ${q.options[0]}\nB) ${q.options[1]}\nC) ${q.options[2]}\nD) ${q.options[3]}\n\nCorrect Answer: ${String.fromCharCode(65 + q.correctAnswer)}\n\nExplanation: ${q.explanation || 'Not provided'}\n\n${'='.repeat(50)}\n`
    ).join('\n');

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mcq-questions.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Downloaded! 📥",
      description: "MCQs exported successfully",
    });
  };

  // Quiz Mode Render
  if (quizMode) {
    const currentQuestion = generatedQuestions[currentQuestionIndex];
    const progress = ((currentQuestionIndex + 1) / generatedQuestions.length) * 100;

    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background/50 to-accent/5 p-2 sm:p-4">
        <div className="container mx-auto max-w-4xl">
          {/* Quiz Header */}
          <Card className="mb-4 sm:mb-6">
            <CardHeader className="pb-3 sm:pb-4">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
                <div>
                  <CardTitle className="text-lg sm:text-xl flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-orange-500" />
                    Quiz Mode
                  </CardTitle>
                  <CardDescription className="text-sm">
                    Question {currentQuestionIndex + 1} of {generatedQuestions.length}
                  </CardDescription>
                </div>
                <Button onClick={resetQuiz} variant="outline" size="sm" className="w-full sm:w-auto">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Exit Quiz
                </Button>
              </div>
              <Progress value={progress} className="w-full mt-3" />
            </CardHeader>
          </Card>

          {!quizCompleted ? (
            /* Current Question */
            <Card className="mb-4 sm:mb-6">
              <CardContent className="pt-4 sm:pt-6">
                <div className="space-y-4 sm:space-y-6">
                  <div className="flex items-start justify-between gap-3">
                    <Badge variant="secondary" className="text-xs sm:text-sm">
                      Question {currentQuestionIndex + 1}
                    </Badge>
                    <Badge variant="outline" className="text-xs sm:text-sm">MCQ</Badge>
                  </div>
                  
                  <h3 className="text-base sm:text-lg font-medium leading-relaxed">
                    {currentQuestion.question}
                  </h3>
                  
                  <div className="space-y-2 sm:space-y-3">
                    {currentQuestion.options.map((option, optionIndex) => {
                      const isSelected = selectedAnswers[currentQuestion.id] === optionIndex;
                      
                      return (
                        <Button
                          key={optionIndex}
                          variant="outline"
                          className={`w-full text-left justify-start h-auto p-3 sm:p-4 text-sm sm:text-base ${
                            isSelected 
                              ? "bg-primary/10 border-primary text-primary" 
                              : "bg-gray-50 border-gray-200 hover:bg-gray-100"
                          } flex items-center`}
                          onClick={() => handleAnswerSelect(currentQuestion.id, optionIndex)}
                        >
                          <span className="font-medium mr-2 sm:mr-3 flex-shrink-0">
                            {String.fromCharCode(65 + optionIndex)})
                          </span>
                          <span className="break-words flex-1 text-left whitespace-pre-wrap">{option}</span>
                        </Button>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            /* Quiz Results */
            <Card className="mb-4 sm:mb-6">
              <CardHeader className="text-center">
                <CardTitle className="text-xl sm:text-2xl flex items-center justify-center gap-2">
                  <Trophy className="w-6 h-6 sm:w-8 sm:h-8 text-yellow-500" />
                  Quiz Completed!
                </CardTitle>
                <CardDescription className="text-base sm:text-lg">
                  Your Score: {quizScore}/{generatedQuestions.length} ({Math.round((quizScore/generatedQuestions.length)*100)}%)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 text-center">
                  <div className="p-3 sm:p-4 bg-blue-50 rounded-lg">
                    <div className="text-lg sm:text-2xl font-bold text-blue-600">{generatedQuestions.length}</div>
                    <div className="text-xs sm:text-sm text-blue-600">Total</div>
                  </div>
                  <div className="p-3 sm:p-4 bg-green-50 rounded-lg">
                    <div className="text-lg sm:text-2xl font-bold text-green-600">{quizScore}</div>
                    <div className="text-xs sm:text-sm text-green-600">Correct</div>
                  </div>
                  <div className="p-3 sm:p-4 bg-red-50 rounded-lg">
                    <div className="text-lg sm:text-2xl font-bold text-red-600">{generatedQuestions.length - quizScore}</div>
                    <div className="text-xs sm:text-sm text-red-600">Wrong</div>
                  </div>
                  <div className="p-3 sm:p-4 bg-purple-50 rounded-lg">
                    <div className="text-lg sm:text-2xl font-bold text-purple-600">{Math.round((quizScore/generatedQuestions.length)*100)}%</div>
                    <div className="text-xs sm:text-sm text-purple-600">Score</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Navigation */}
          <div className="flex flex-col sm:flex-row justify-between gap-3 sm:gap-4">
            {!quizCompleted ? (
              <>
                <Button 
                  onClick={previousQuestion} 
                  disabled={currentQuestionIndex === 0}
                  variant="outline"
                  className="w-full sm:w-auto"
                >
                  Previous
                </Button>
                <Button 
                  onClick={nextQuestion}
                  disabled={!selectedAnswers[currentQuestion.id] && selectedAnswers[currentQuestion.id] !== 0}
                  className="w-full sm:w-auto"
                >
                  {currentQuestionIndex === generatedQuestions.length - 1 ? 'Finish Quiz' : 'Next Question'}
                </Button>
              </>
            ) : (
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 w-full">
                <Button onClick={resetQuiz} variant="outline" className="w-full sm:w-auto">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
                <Button onClick={() => setQuizMode(false)} className="w-full sm:w-auto">
                  View All Questions
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/50 to-accent/5 p-2 sm:p-4">
      <div className="container mx-auto max-w-4xl">
        {/* Header */}
        <div className="mb-4 sm:mb-6 space-y-3 sm:space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-3">
            <div className="p-2 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl shadow-lg">
              <Brain className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <div className="flex-1">
              <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground">
                MCQ Generator
              </h1>
              <p className="text-sm sm:text-base text-muted-foreground">
                Generate important MCQs and PYQs for CBSE Class 10th
              </p>
            </div>
          </div>
        </div>

        {/* Generator Form */}
        <Card className="mb-4 sm:mb-6">
          <CardHeader>
            <CardTitle className="text-base sm:text-lg flex items-center gap-2">
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
              Generate MCQ Questions
            </CardTitle>
            <CardDescription className="text-sm">
              Select your subject and chapter to generate important MCQs and previous year questions
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              <div className="space-y-2">
                <Label htmlFor="subject" className="text-sm">Subject</Label>
                <Select value={formData.selectedSubject} onValueChange={(value) => setFormData(prev => ({ ...prev, selectedSubject: value, selectedChapter: '' }))}>
                  <SelectTrigger className="h-10 sm:h-11">
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subject) => (
                      <SelectItem key={subject.id} value={subject.id}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="chapter" className="text-sm">Chapter</Label>
                <Select 
                  value={formData.selectedChapter} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, selectedChapter: value }))}
                  disabled={!formData.selectedSubject}
                >
                  <SelectTrigger className="h-10 sm:h-11">
                    <SelectValue placeholder="Select chapter" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableChapters.map((chapter) => (
                      <SelectItem key={chapter.id} value={chapter.id}>
                        {chapter.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="count" className="text-sm">Number of Questions</Label>
                <Select value={formData.questionCount} onValueChange={(value) => setFormData(prev => ({ ...prev, questionCount: value }))}>
                  <SelectTrigger className="h-10 sm:h-11">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 Questions</SelectItem>
                    <SelectItem value="10">10 Questions</SelectItem>
                    <SelectItem value="15">15 Questions</SelectItem>
                    <SelectItem value="20">20 Questions</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <Button 
              onClick={generateMCQs}
              disabled={isLoading || !formData.selectedSubject || !formData.selectedChapter}
              className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 h-10 sm:h-11"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Generating MCQs...
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4 mr-2" />
                  Generate Important MCQs
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Generated MCQs */}
        {generatedQuestions.length > 0 && (
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
                <div>
                  <CardTitle className="text-base sm:text-lg flex items-center gap-2">
                    <Brain className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                    MCQ Questions ({generatedQuestions.length})
                  </CardTitle>
                  <CardDescription className="text-sm">
                    Important questions and PYQs for practice
                  </CardDescription>
                </div>
                <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                  <Button onClick={startQuizMode} className="w-full sm:w-auto bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700">
                    <Play className="w-4 h-4 mr-2" />
                    Start Quiz Mode
                  </Button>
                  {Object.keys(selectedAnswers).length > 0 && !showResults && (
                    <Button onClick={checkAnswers} variant="outline" className="w-full sm:w-auto">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Check Answers
                    </Button>
                  )}
                  {showResults && (
                    <Button onClick={resetQuiz} variant="outline" className="w-full sm:w-auto">
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Reset
                    </Button>
                  )}
                  <Button onClick={exportMCQs} variant="outline" className="w-full sm:w-auto">
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4 sm:space-y-6">
              {generatedQuestions.map((question, index) => (
                <Card key={question.id} className="border-l-4 border-l-orange-500">
                  <CardContent className="pt-4">
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-3 mb-4">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="text-xs sm:text-sm">Question {index + 1}</Badge>
                        <Badge variant="outline" className="text-xs sm:text-sm">MCQ</Badge>
                      </div>
                      <div className="flex gap-2 w-full sm:w-auto">
                        <Button
                          onClick={() => toggleSolution(question.id)}
                          variant="ghost"
                          size="sm"
                          className="flex-1 sm:flex-none"
                        >
                          <Target className="w-4 h-4 mr-2" />
                          {showSolutions[question.id] ? 'Hide' : 'Get'} Solution
                        </Button>
                        <Button
                          onClick={() => copyQuestion(question)}
                          variant="ghost"
                          size="sm"
                          className="flex-1 sm:flex-none"
                        >
                          <Copy className="w-4 h-4 mr-2" />
                          Copy
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h4 className="font-medium text-foreground leading-relaxed text-sm sm:text-base">
                        {question.question}
                      </h4>
                      
                      <div className="space-y-2">
                        {question.options.map((option, optionIndex) => {
                          const isSelected = selectedAnswers[question.id] === optionIndex;
                          const isCorrect = optionIndex === question.correctAnswer;
                          const showResult = showResults;
                          
                          let buttonClass = "w-full text-left justify-start h-auto p-3 text-sm sm:text-base ";
                          if (showResult) {
                            if (isCorrect) {
                              buttonClass += "bg-green-100 border-green-500 text-green-800 hover:bg-green-100 ";
                            } else if (isSelected && !isCorrect) {
                              buttonClass += "bg-red-100 border-red-500 text-red-800 hover:bg-red-100 ";
                            } else {
                              buttonClass += "bg-gray-50 border-gray-200 text-gray-600 ";
                            }
                          } else {
                            buttonClass += isSelected 
                              ? "bg-primary/10 border-primary text-primary " 
                              : "bg-gray-50 border-gray-200 hover:bg-gray-100 ";
                          }
                          
                          return (
                            <Button
                              key={optionIndex}
                              variant="outline"
                              className={`${buttonClass} flex items-center`}
                              onClick={() => !showResults && handleAnswerSelect(question.id, optionIndex)}
                              disabled={showResults}
                            >
                              <span className="font-medium mr-2 sm:mr-3 flex-shrink-0">
                                {String.fromCharCode(65 + optionIndex)})
                              </span>
                              <span className="break-words flex-1 text-left whitespace-pre-wrap">{option}</span>
                              {showResult && isCorrect && (
                                <CheckCircle className="w-4 h-4 ml-auto text-green-600 flex-shrink-0" />
                              )}
                            </Button>
                          );
                        })}
                      </div>
                      
                      {(showResults || showSolutions[question.id]) && question.explanation && (
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <h5 className="font-medium text-blue-800 mb-2 text-sm sm:text-base">Explanation:</h5>
                          <p className="text-blue-700 text-xs sm:text-sm leading-relaxed">
                            {question.explanation}
                          </p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Tips */}
        <Card className="mt-4 sm:mt-6 bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
          <CardHeader>
            <CardTitle className="text-base sm:text-lg flex items-center gap-2">
              <Brain className="w-4 h-4 sm:w-5 sm:h-5 text-orange-600" />
              MCQ Practice Tips
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm">
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-orange-500 rounded-full mt-1.5 flex-shrink-0"></div>
                <p className="text-muted-foreground">Focus on important concepts and formulas</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-orange-500 rounded-full mt-1.5 flex-shrink-0"></div>
                <p className="text-muted-foreground">Practice PYQ patterns regularly</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-orange-500 rounded-full mt-1.5 flex-shrink-0"></div>
                <p className="text-muted-foreground">Read all options carefully before answering</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-orange-500 rounded-full mt-1.5 flex-shrink-0"></div>
                <p className="text-muted-foreground">Review explanations to understand concepts</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MCQGeneratorPage;

