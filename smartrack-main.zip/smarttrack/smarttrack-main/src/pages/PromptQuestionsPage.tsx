import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from "@/hooks/use-toast";
import { Brain, Sparkles, Copy, Download, Wand2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface GeneratedQuestion {
  id: string;
  question: string;
  type: 'short' | 'long';
  answer?: string;
  marks?: number;
}

const PromptQuestionsPage: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [questionCount, setQuestionCount] = useState('5');
  const [isLoading, setIsLoading] = useState(false);
  const [generatedQuestions, setGeneratedQuestions] = useState<GeneratedQuestion[]>([]);
  const { toast } = useToast();

  const generateQuestions = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Missing Prompt",
        description: "Please enter a prompt to generate questions",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      const aiPrompt = `Based on the following prompt: "${prompt}"

Generate exactly ${questionCount} questions in the following format:

For each question, provide:
1. Question type (SHORT or LONG)
2. The question text
3. Marks allocation (1-2 marks for short, 3-5 marks for long)
4. A brief answer/solution

Format your response as:
**Question 1: [SHORT/LONG] - [X marks]**
[Question text]

**Answer:**
[Brief answer/solution]

---

Make sure to:
- Generate a mix of short answer (1-2 marks) and long answer (3-5 marks) questions
- Focus on important concepts and PYQs (Previous Year Questions) style
- Ensure questions are clear and well-structured
- Provide concise but complete answers
- Make questions suitable for CBSE Class 10th level`;

      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyDi1wHRLfS2-g4adHzuVfZRzmI4tRrzH-U`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: aiPrompt
            }]
          }]
        })
      });

      if (!response.ok) {
        throw new Error('Failed to generate questions');
      }

      const data = await response.json();
      const generatedText = data.candidates[0].content.parts[0].text;
      
      // Parse the generated questions
      const questions = parseGeneratedQuestions(generatedText);
      setGeneratedQuestions(questions);
      
      toast({
        title: "Questions Generated Successfully! 🎉",
        description: `Created ${questions.length} questions from your prompt`,
      });

    } catch (error) {
      console.error('Error generating questions:', error);
      toast({
        title: "Generation Failed",
        description: "Unable to create questions right now. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const parseGeneratedQuestions = (text: string): GeneratedQuestion[] => {
    const questions: GeneratedQuestion[] = [];
    const questionBlocks = text.split('---').filter(block => block.trim());

    questionBlocks.forEach((block, index) => {
      const lines = block.trim().split('\n').filter(line => line.trim());
      
      if (lines.length > 0) {
        const firstLine = lines[0];
        const questionMatch = firstLine.match(/\*\*Question \d+: (SHORT|LONG) - (\d+) marks?\*\*/i);
        
        if (questionMatch) {
          const type = questionMatch[1].toLowerCase() as 'short' | 'long';
          const marks = parseInt(questionMatch[2]);
          
          // Find question text (after the header, before "**Answer:**")
          let questionText = '';
          let answerText = '';
          let isAnswer = false;
          
          for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();
            if (line.startsWith('**Answer:**')) {
              isAnswer = true;
              continue;
            }
            
            if (isAnswer) {
              answerText += line + ' ';
            } else if (line && !line.startsWith('**')) {
              questionText += line + ' ';
            }
          }
          
          if (questionText.trim()) {
            questions.push({
              id: `prompt-q-${index + 1}`,
              question: questionText.trim(),
              type,
              marks,
              answer: answerText.trim() || undefined
            });
          }
        }
      }
    });

    return questions;
  };

  const copyQuestion = (question: GeneratedQuestion) => {
    const text = `${question.question}\n\n${question.answer ? `Answer: ${question.answer}` : ''}`;
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied! 📋",
      description: "Question copied to clipboard",
    });
  };

  const exportQuestions = () => {
    const content = generatedQuestions.map((q, index) => 
      `Question ${index + 1}: [${q.type.toUpperCase()}] - ${q.marks} marks\n${q.question}\n\nAnswer:\n${q.answer || 'Answer not provided'}\n\n${'='.repeat(50)}\n`
    ).join('\n');

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'prompt-generated-questions.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Downloaded! 📥",
      description: "Questions exported successfully",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/50 to-accent/5">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Header */}
        <div className="mb-6 space-y-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-green-500 to-blue-500 rounded-xl shadow-lg">
              <Wand2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-foreground">
                Prompt Question Generator
              </h1>
              <p className="text-sm md:text-base text-muted-foreground">
                Generate questions using custom prompts - PYQs and important questions
              </p>
            </div>
          </div>
        </div>

        {/* Input Form */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              Enter Your Prompt
            </CardTitle>
            <CardDescription>
              Describe the topic, subject, or specific area you want questions about
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="prompt">Question Prompt</Label>
              <Textarea
                id="prompt"
                placeholder="e.g., 'Light reflection and refraction for Class 10 Physics', 'Quadratic equations important questions', 'Life processes biology PYQs'..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                disabled={isLoading}
                className="min-h-[100px]"
              />
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="space-y-2 flex-1">
                <Label htmlFor="count">Number of Questions</Label>
                <Input
                  id="count"
                  type="number"
                  min="1"
                  max="10"
                  value={questionCount}
                  onChange={(e) => setQuestionCount(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              
              <div className="flex items-end">
                <Button 
                  onClick={generateQuestions}
                  disabled={isLoading || !prompt.trim()}
                  className="w-full sm:w-auto bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
                >
                  {isLoading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate Questions
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Generated Questions */}
        {generatedQuestions.length > 0 && (
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-primary" />
                    Generated Questions ({generatedQuestions.length})
                  </CardTitle>
                  <CardDescription>
                    Mix of short and long answer questions with proper formatting
                  </CardDescription>
                </div>
                <Button 
                  onClick={exportQuestions}
                  variant="outline"
                  className="w-full sm:w-auto"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export All
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {generatedQuestions.map((question, index) => (
                <Card key={question.id} className="border-l-4 border-l-primary">
                  <CardContent className="pt-4">
                    <div className="flex flex-col sm:flex-row justify-between items-start gap-3 mb-3">
                      <div className="flex items-center gap-2">
                        <Badge variant={question.type === 'short' ? 'secondary' : 'default'}>
                          {question.type.toUpperCase()}
                        </Badge>
                        <Badge variant="outline">
                          {question.marks} marks
                        </Badge>
                      </div>
                      <Button
                        onClick={() => copyQuestion(question)}
                        variant="ghost"
                        size="sm"
                        className="w-full sm:w-auto"
                      >
                        <Copy className="w-4 h-4 mr-2" />
                        Copy
                      </Button>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <h4 className="font-medium text-foreground mb-2">
                          Question {index + 1}:
                        </h4>
                        <p className="text-muted-foreground leading-relaxed">
                          {question.question}
                        </p>
                      </div>
                      
                      {question.answer && (
                        <div className="bg-muted/50 rounded-lg p-3">
                          <h5 className="font-medium text-foreground mb-2">Answer:</h5>
                          <p className="text-muted-foreground text-sm leading-relaxed">
                            {question.answer}
                          </p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Tips */}
        <Card className="mt-6 bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              Tips for Better Questions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full mt-1.5 flex-shrink-0"></div>
                <p className="text-muted-foreground">Be specific about the topic or chapter</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full mt-1.5 flex-shrink-0"></div>
                <p className="text-muted-foreground">Mention "PYQs" for previous year style questions</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full mt-1.5 flex-shrink-0"></div>
                <p className="text-muted-foreground">Include subject name for better context</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full mt-1.5 flex-shrink-0"></div>
                <p className="text-muted-foreground">Ask for "important questions" for exam focus</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PromptQuestionsPage;

