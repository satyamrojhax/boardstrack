import React from 'react';
import { QuestionGenerator } from '@/components/QuestionGenerator/index';
import { Brain } from 'lucide-react';

const QuestionsPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/50 to-accent/5">
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        {/* Simplified Header */}
        <div className="mb-6 space-y-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-purple-500 to-blue-500 rounded-xl shadow-lg">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-foreground">
                Smart Question Generator
              </h1>
              <p className="text-sm md:text-base text-muted-foreground">
                Generate unlimited practice questions for your studies
              </p>
            </div>
          </div>
        </div>

        {/* Main Question Generator */}
        <div className="w-full">
          <QuestionGenerator />
        </div>
      </div>
    </div>
  );
};

export default QuestionsPage;

