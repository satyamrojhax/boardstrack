import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { AuthContextProps, Profile, LoginData, SignupData, ProfileUpdateData } from '@/types/auth';
import { fetchProfile, ensureUserDataTracking } from '@/services/profileService';
import { loginUser, signupUser, logoutUser } from '@/services/authService';
import { updateProfileInDB } from '@/services/profileService';

const AuthContext = createContext<AuthContextProps>({
  user: null,
  profile: null,
  session: null,
  login: async () => ({ success: false }),
  signup: async () => ({ success: false }),
  logout: () => {},
  updateProfile: async () => ({ success: false }),
  isLoading: true,
});

const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Cache for profile data
  const profileCache = new Map<string, Profile>();

  // Optimized profile fetching with caching
  const fetchUserProfile = async (userId: string) => {
    try {
      // Check cache first
      if (profileCache.has(userId)) {
        const cachedProfile = profileCache.get(userId)!;
        setProfile(cachedProfile);
        return;
      }

      console.log('Fetching profile for user:', userId);
      const profileData = await fetchProfile(userId);
      if (profileData) {
        // Cache the profile
        profileCache.set(userId, profileData);
        setProfile(profileData);
        
        // Ensure user data tracking is set up (non-blocking)
        ensureUserDataTracking(userId).catch(console.error);
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      // Create a fallback profile to prevent app from being stuck
      const fallbackProfile = {
        id: userId,
        name: 'User',
        email: user?.email || '',
        class: 'class-10',
        board: 'cbse',
        role: 'student' as const
      };
      setProfile(fallbackProfile);
      profileCache.set(userId, fallbackProfile);
    }
  };

  // Initialize auth state with faster loading
  useEffect(() => {
    let mounted = true;

    const initializeAuth = async () => {
      try {
        // Get initial session immediately
        const { data: { session: initialSession }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Error getting session:', error);
          if (mounted) {
            setIsLoading(false);
          }
          return;
        }

        if (initialSession?.user && mounted) {
          setUser(initialSession.user);
          setSession(initialSession);
          
          // Fetch profile in parallel, don't wait for it
          fetchUserProfile(initialSession.user.id);
        }

        if (mounted) {
          setIsLoading(false);
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    // Initialize immediately
    initializeAuth();

    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!mounted) return;

        console.log('Auth state changed:', event, session?.user?.id);
        
        if (session?.user) {
          setUser(session.user);
          setSession(session);
          
          // Fetch profile for new user
          if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
            fetchUserProfile(session.user.id);
          }
        } else {
          setUser(null);
          setSession(null);
          setProfile(null);
          // Clear cache on logout
          profileCache.clear();
        }
        
        setIsLoading(false);
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  // Optimized login function
  const login = async (data: LoginData) => {
    try {
      setIsLoading(true);
      const result = await loginUser(data);
      
      if (result.success && result.user) {
        // Profile will be fetched by auth state change listener
        return { success: true };
      }
      
      return result;
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: 'Login failed' };
    } finally {
      setIsLoading(false);
    }
  };

  // Optimized signup function
  const signup = async (data: SignupData) => {
    try {
      setIsLoading(true);
      const result = await signupUser(data);
      
      if (result.success && result.user) {
        // Profile will be fetched by auth state change listener
        return { success: true };
      }
      
      return result;
    } catch (error) {
      console.error('Signup error:', error);
      return { success: false, error: 'Signup failed' };
    } finally {
      setIsLoading(false);
    }
  };

  // Optimized logout function
  const logout = async () => {
    try {
      await logoutUser();
      // Clear cache
      profileCache.clear();
      setUser(null);
      setSession(null);
      setProfile(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  // Optimized profile update function
  const updateProfile = async (data: ProfileUpdateData) => {
    if (!user) return { success: false, error: 'No user logged in' };

    try {
      const result = await updateProfileInDB(user.id, data);
      
      if (result.success && result.profile) {
        // Update cache
        profileCache.set(user.id, result.profile);
        setProfile(result.profile);
      }
      
      return result;
    } catch (error) {
      console.error('Profile update error:', error);
      return { success: false, error: 'Failed to update profile' };
    }
  };

  const value: AuthContextProps = {
    user,
    profile,
    session,
    login,
    signup,
    logout,
    updateProfile,
    isLoading,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

const useAuth = (): AuthContextProps => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export { AuthProvider, useAuth };

